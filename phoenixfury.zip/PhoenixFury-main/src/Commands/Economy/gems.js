
const path = require('path');
const fs = require('fs').promises;

// Wallet Command
module.exports = {
    name: 'coin',
    aliases: ['ac', 'coins'],
    category: 'economy',
    exp: 1,
    cool: 4,
    react: "✅",
    usage: 'Use :wallet',
    description: 'Shows the wallet value',
    async execute(client, arg, M) {
        try {
            const userId = M.sender;
            let economy = await client.econ.findOne({ userId });

            if (!economy) {
                economy = new client.econ({ userId, coin: 0 });
                await economy.save();
            }

            let wallet = economy.coin || 0;

            // Ensure wallet value is an integer
            wallet = Math.round(wallet);

            if (wallet < 0) { // Check if wallet is negative
                economy.coin = 0; // Set wallet to 0 if negative
                await economy.save();
            } else if (wallet !== Math.round(wallet)) { // Check if wallet is not an integer
                economy.coin = Math.round(wallet); // Round down wallet value to nearest integer
                await economy.save();
            }

            const username = M.pushName;
            const tag = `#${M.sender.substring(3, 7)}`;
            const thumbnailPath = path.join(__dirname, '..', '..', '..', 'assets', 'images', 'coin.png');

            // Read the thumbnail image file
            const thumbnail = await fs.readFile(thumbnailPath);

            await client.sendMessage(M.from, {
                image: thumbnail,
                caption: `💰 *${username}* ${tag}\n\n🪙 *Coins:* ${wallet}`
            }, { quoted: M });

        } catch (error) {
            console.error('Error in gems command:', error);
            M.reply('❌ An error occurred while fetching your wallet information.');
        }
    }
};
