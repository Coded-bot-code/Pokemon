
const axios = require('axios');

module.exports = {
    name: 'treasury',
    aliases: ['at'],
    category: 'economy',
    exp: 1,
    cool: 4,
    react: "✅",
    usage: 'Use: !treasury',
    description: 'Shows the treasury value',

    async execute(client, arg, M) {
        try {
            const userId = M.sender;
            let economy = await client.econ.findOne({ userId });

            if (!economy) {
                economy = new client.econ({ userId, treasurys: 0 });
                await economy.save();
            }

            // Default treasury value if no economy data is found
            const treasury = economy.treasurys || 0;

            const username = M.pushName;
            const tag = `#${M.sender.substring(3, 7)}`;

            // Fetch the thumbnail image from a URL
            const { data: thumbnailBuffer } = await axios({
                url: 'https://i.ibb.co/YypVrb6/treasury.png',
                responseType: 'arraybuffer'
            });

            await client.sendMessage(M.from, {
                image: Buffer.from(thumbnailBuffer),
                caption: `🏛️ *${username}* ${tag}\n\n💎 *Treasury:* ${treasury}`
            }, { quoted: M });

        } catch (error) {
            console.error('Error in treasury command:', error);
            M.reply('❌ An error occurred while fetching your treasury information.');
        }
    }
};
