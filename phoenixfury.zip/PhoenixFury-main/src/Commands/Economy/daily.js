const ms = require('parse-ms');

module.exports = {
    name: 'daily',
    aliases: ['rewards'],
    category: 'economy',
    exp: 1,
    react: "✅",
    description: 'Claims your daily rewards',
    async execute(client, arg, M) {
        const dailyTimeout = 86400000; // 24 hours
        const baseDailyAmount = 1000;
        const userId = M.sender;
        let message = '';

        // Fetch economy data
        let economy = await client.econ.findOne({ userId });
        if (!economy) {
            economy = new client.econ({ userId, coin: 0, streak: 0, lastDaily: null });
        }

        const daily = economy.lastDaily;

        if (daily !== null && dailyTimeout - (Date.now() - daily) > 0) {
            const dailyTime = ms(dailyTimeout - (Date.now() - daily));
            message = `*You have already claimed your daily reward. Wait ${dailyTime.hours} hour(s), ${dailyTime.minutes} minute(s), and ${dailyTime.seconds} second(s).*`;
        } else {
            // Check streaks
            if (daily !== null && Date.now() - daily < 2 * dailyTimeout) {
                economy.streak = (economy.streak || 1) + 1;
            } else {
                economy.streak = 1; // Reset streak if missed 2 consecutive days
            }

            // Calculate reward
            const dailyAmount = baseDailyAmount * (1 + (economy.streak - 1) / 4);
            economy.coin += Math.floor(dailyAmount);
            economy.lastDaily = Date.now();

            await economy.save();

            message = `*You have claimed your daily reward of ${Math.floor(dailyAmount)} coins!*\n*Current streak: ${economy.streak} days*`;
        }

        M.reply(message);
    }
};