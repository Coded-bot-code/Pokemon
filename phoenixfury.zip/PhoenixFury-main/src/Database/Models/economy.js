// Economy model for WhatsApp bot database
const mongoose = require('mongoose');

const economySchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true,
        unique: true
    },
    coin: {
        type: Number,
        default: 0
    },
    treasurys: {
        type: Number,
        default: 0
    },
    bank: {
        type: Number,
        default: 0
    },
    lastDaily: {
        type: Date,
        default: null
    },
    streak: {
        type: Number,
        default: 0
    },
    lastRob: {
        type: Date,
        default: null
    },
    inventory: {
        type: Array,
        default: []
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Economy', economySchema);