const groups = () => {
    return {
        casinoGroup: "120363265227464577@g.us",
        modsGroup: "120363333613340467@g.us",
        supportGroup: "120363281892304546@g.us",
        auctionGroup: "120363294394559073@g.us",
        gamesGroup: "120363306815978726@g.us",
        statusGroup: "120363303890527858@g.us",
        battleGroup: "120363333613340467@g.us",
        eventsGroup: "",
    };
};

module.exports = {
    groups
};
