<h1 align="center"> PHOENIX 

</div>
<p align="center">
  
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRevBll52JIK90iRAzEXZYHffkGAjPknwv9vSwraePZqjaOZsTsMRm3Ank&s=10" width="360" border="0" alt="PFP">
</h3>

<p align="center">
Phoenix

ᴀɴ ᴀᴅᴠᴀɴᴄᴇ ɴᴇᴡ ɢᴇɴᴇʀᴀᴛɪᴏɴ ʙᴏᴛ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴛᴇᴀᴍ ᴀᴜʀᴏʀᴀ. ꜰʀᴏᴍ ᴏᴜʀ ᴅᴇᴠʟᴏᴘᴇʀs ʏᴏᴜ ɢᴜʏs ᴀʀᴇ ᴠᴇʀʏ ᴛʜᴀɴᴋᴇᴅ ꜰᴏʀ ᴜsɪɴɢ ᴏᴜʀ ᴘʀᴏᴊᴇᴄᴛ ᴀs ʏᴏᴜʀ ʙᴀsᴇ ʙᴏᴛ.
<h3 align="center"> ᴄᴇʟᴇꜱᴛɪᴄ ʙᴏᴛ - ᴛʜᴇ ғᴜᴛᴜʀᴇ ɪꜱ ʜᴇʀᴇ
<P align="center"> [ ϙʀ ꜱᴄᴀɴ ] ɪɴᴅɪʀᴇᴄᴛʟʏ ғʀᴏᴍ ʀᴇᴘᴏ ᴅᴇᴘʟᴏʏɪɴɢ
</h4>

## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=FF0000&lines=ɪ'ᴍ+phoenix-ʙᴏᴛ+ᴀɴ+ᴀɪ+ʙᴏᴛ;ᴍᴀᴅᴇ+ʙʏ+ᴛᴇᴀᴍ-phoenix;ᴅᴇʟɪɢʜᴛ+ᴡᴇʟᴄᴏᴍᴇ+ᴛᴏ+ᴇᴠᴇʀʏᴏɴᴇ;ᴛʜᴇ+ғᴜᴛᴜʀᴇ+ɪꜱ+ʜᴇʀᴇ;ʜᴀᴠᴇ+ᴀ+ɢᴏᴏᴅ+ᴅᴀʏ;ᴛᴏ+ɢᴇᴛ+ʏᴏᴜʀ+ᴡʜᴀᴛꜱᴀᴘᴘ+ɴᴇꭗᴛ+ʟᴇᴠᴇʟ;aurora-ʙᴏᴛ+ᴍᴜʟᴛɪᴘʟᴇ+ᴅᴇᴠɪᴄᴇꜱ.)](https://git.io/typing-svg)
<br>
<div align="center">
<a href="https://chat.whatsapp.com/L3J8tp04lzUBZbd1bTitSI" target="blank"><img src="https://img.shields.io/badge/GC link-000000?style=for-the-badge&logo=whatsapp&logoColor=white" height="25px"/></a>
<a href="https://chat.whatsapp.com/DrY5MBaiDRS9BAcpCpJQCv" target="blank"><img src="https://img.shields.io/badge/Creator's - Team phoenix-000000?style=for-the-badge&logo=github&logoColor=white" height="25px"/></a>  </a>
  <br>

<a><img src="https://i.ibb.co/7Kk6XSg/Rainbow.gif" width="100%">


---

<h2> 🎐 ᴅᴇᴘʟᴏʏ ᴀɴʏ ᴘʟᴀᴛғᴏʀᴍ 🎐
</h2> 
Click here<details Close>

<summary></summary>

<h4 align="center" >
    <a href="https://heroku.com/deploy?template=https://github.com/Kingshisui00/Aurora-Private">
    <img src="https://www.herokucdn.com/deploy/button.svg" width="150px" alt="Deploy on Heroku" >
    </a>

<h4 align="center"> 
<a href="https://app.koyeb.com/apps/deploy?type=docker&image=quay.io/Kingshisui/phoenix-Private:main&env[PORT]=3000&env[PREFIX]=-&&env[MONGODB]=mongodb://mongo:a2H5ECgq2f3z1eW8DwGY@containers-us-west-24.railway.app:5516&&env[SESSION]=enterYourSession&&env[MODS]=917973456275&&env[Chat_Bot_Url]=http://api.brainshop.ai/get?bid=[bid]&key=[key]&uid=[uid]&msg=[msg]">
    <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy on Koyeb" width="140px">
    </a>

<h4 align="center"> 
<a href="https://railway.app">
<img src="https://railway.app/button.svg" alt="Deploy on Railway" width="150px">
</a>
 
<h4 align="center"> 
<a href="https://repl.it/github/Aurora-Private">
<img src= "https://img.shields.io/badge/replit-253c99?style=for-the-badge&logo=replit&logoColor=F26207"alt="Deploy on Replit" width="150px">
</a>
</p>
</h4>

</div>

</details>

<a><img src="https://i.ibb.co/7Kk6XSg/Rainbow.gif" width="100%">

## Highlights

---

-   Written with [NodeJS](https://nodejs.org/)
-   Fully updated whatsapp baileys bot and runs easily on [WHATSAPP](https://www.whatsapp.com/).
-   Easy to maintenace without turning off the bot in github editor [CODESPACE](https://github.com/codespaces).
-   Made with [Baileys](https://github.com/WhiskeySockets/Baileys) - MD (Best Library right now) for whatsapp.
-   Using mongodb atlas (cluster example is in [app.json](https://github.com/Kingshisui00/Aurora-Private/blob/main/app.json)) (helper [MongoDB_Guide.md](https://github.com/Kingshisui00/Aurora-Private/blob/main/MongoDB_Guide.md))
-   Suitable for those who want to learn Java Script programming and whatsapp bot programming. 

---

>
      
ENV | VALUES
-- | --
NAME | The name of your bot (Aurora-Public) 
PREFIX | The prefix of your bot can be a symbol (:)
MODS | Phone numbers in this format (`918961331275`) without `+` or `SPACE` and for more numbers put a "," between them.
PORT | The port on which your bot will run (3000)
WRITE_SONIC | A write sonic key for your bot ()
BG_API_KEY | An Api key for remove background feature ()
OPENAi | An Api key for the chat got feature ()
MONGODB | Your MongoDB URL ()
SESSION | Any random value and try to keep it copied.
SESSION_URL | Your Mongo URL will be used here ()
  
<br>
      
- Next click on `Green Run button` in Repl.it to start bot installation.
- After it's deployed an webpage should appear there the QR will be generated.
- Scan the QR from WhatsApp ---> Linked devices ---> Link a device.
- UptimeRobot will prevent Repl.it's auto sleep.
- If you are having issues contact us. 
      
<br>
      
      
  
      
ENV | VALUES
-- | --
NAME | The name of your bot (phoenix-Public) 
PREFIX | The prefix of your bot can be a symbol (:)
MODS | Phone numbers in this format (`917973456275`) without `+` or `SPACE` and for more numbers put a "," between them.
PORT | The port on which your bot will run (3000)
WRITE_SONIC | A write sonic key for your bot ()
BG_API_KEY | An Api key for remove background feature ()
OPENAi | An Api key for the chat got feature ()
MONGODB | Your MongoDB URL ()
SESSION | Any random value and try to keep it copied
SESSION_URL | Your Mongo URL will be used here ()
  
<br>
      
- Next start deploy and wait for 3-4 minutes.
- After it's done click on `Manage App`.
- Next on the deploy part connect to your forked repo and turn on automatic deployment on`
- After that go to More ---> view logs and wait for qr to appear.
- When you see broken QRs are appearing chick on `Open app` then the we will be generated.
- Scan the QR from WhatsApp ---> Linked devices ---> Link a device.
      
<br>

ENV | VALUES
-- | --
NAME | The name of your bot (phoenix-Public) 
PREFIX | The prefix of your bot can be a symbol (:)
MODS | Phone numbers in this format (`917973456275`) without `+` or `SPACE` and for more numbers put a "," between them.
PORT | The port on which your bot will run (3000)
WRITE_SONIC | A write sonic key for your bot ()
BG_API_KEY | An Api key for remove background feature ()
OPENAi | An Api key for the chat got feature ()
MONGODB | Your MongoDB URL ()
SESSION | Any random value and try to keep it copied
SESSION_URL | Your Mongo URL will be used here ()
 
- 5-6 minutes later when Deploy is completed click on that generated domain to go to QR page.
- just put your Previously copied `Session ID` and click on `Get QR`.
- Scan the QR from WhatsApp ---> Linked devices ---> Link a device.
- If you are having issues contact us.
      
<br>
      
ENV | VALUES
-- | --
NAME | The name of your bot (phoenix-Public) 
PREFIX | The prefix of your bot can be a symbol (:)
MODS | Phone numbers in this format (`917973456275`) without `+` or `SPACE` and for more numbers put a "," between them.
PORT | The port on which your bot will run (3000)
WRITE_SONIC | A write sonic key for your bot ()
BG_API_KEY | An Api key for remove background feature ()
OPENAi | An Api key for the chat got feature ()
MONGODB | Your MongoDB URL ()
SESSION | Any random value and try to keep it copied
SESSION_URL | Your Mongo URL will be used here ()
  
<br>
      
- 10 minutes later when Deploy is completed click on that generated weblink to go to QR page.
- just put your Previously copied `Session ID` and click on `Get QR`.
- Scan the QR from WhatsApp ---> Linked devices ---> Link a device.
- If you are having issues contact us.

<br>
      
ENV | VALUES
-- | --
NAME | The name of your bot (phoenix-Public) 
PREFIX | The prefix of your bot can be a symbol (:)
MODS | Phone numbers in this format (`7973456275`) without `+` or `SPACE` and for more numbers put a "," between them.
PORT | The port on which your bot will run (3000)
WRITE_SONIC | A write sonic key for your bot ()
BG_API_KEY | An Api key for remove background feature ()
OPENAi | An Api key for the chat got feature ()
MONGODB | Your MongoDB URL ()
SESSION | Any random value and try to keep it copied
SESSION_URL | Your Mongo URL will be used here ()
  
<br>
      
- If you are having issues contact us.

<br><br> 



## HOW TO MAKE MY BOT ALWAYS TURNED ON?
-> Here is a solution for you the [UptimeRobot](https://uptimerobot.com/) website.
Create an account there.
After yoour scan is done and bot is connected comeback copy the link of web from where you scanned(replit, heroku, railway, koyeb or codespace) and paste it as an HTTPS monitor in the web and your job is done. 

</details>
---

## Getting Started

This project require

- [NodeJS](https://nodejs.org/en/download/) [v16 or greater](https://nodejs.org/dist/)
- [FFMPEG](https://ffmpeg.org/download.html)
- [@whiskeysocketBaileys](https://github.com/WhiskeySockets/Baileys)
- [APIS]()
- Yarn lock file

## Install


<section>

### Clone this project

```bash
git clone https://github.com/PhoenixFury0000/phoenix-Private.git
cd phoenixfury-Public
```

### Install the dependencies:

```bash
yarn add <Package_Name>
```

### Setup

Create .env file based on .env.example, copy the mongo database URL into .env file

```bash
NAME=phoenix-Public
PREFIX=:
MODS=917973456xxx
PORT=3000
WRITE_SONIC=
BG_API_KEY=
SESSION=
URL=mongodb+srv://<username>:<password>@cluster0.xxwc771.mongodb.net/?retryWrites=true&w=majority
SESSION_URL=same as url
```

</section>

## Contributing

<section>

If you've ever wanted to contribute to our project and want to be our part here is your chance guys!

-   If you had created any new function regarding the bot feel free to test it and if it works contact our DEVLOPERS to add it to the official repo. 
-   Make sure to follow the ESLint Rules while editing the code and run `yarn start format` before opening PRs
-   If you want to contribute

    1. Fork this repository
    2. edit/change what you want, for example you want to add features/fix bugs/creste new features/new updates 
    3. Test it first if its working without any bug or not
    4. You can submit a pull request
    5. Contact with the devs and show them your tested function and let them approve.
    6. If it accepts then delete the old fork and the new fork if you want to pull the request again.
    7. Help us by providing more features and we will surely dont forget to thank you in our repo.

</section>

## License

<section>

since **whatsapp-bot** use [baileys](https://github.com/WhiskeySockets/Baileys) is now available under the GPL-3.0 license. See the [LICENSE](LICENSE) file for more info.

</section>

---


<h2 align="center">🖤 Key Features 🖤
</h2>

<br>

- Fully new updated baileys whatsapp bot running very smoothly by deploying.
- Fully powered by MongoDb.
- Self / public / private modes.
- Single prefix ( ":" ).
- RPG and Economy added ( More coming soon ).
- Group Chatbot and AI functions with media category. 
- Have even section for anime related commands.
- Highest Commands and Features.
- User / group Banning and command toggling function.
- Highest Security compared to most other public bots.
- Major user required command for users.

<h2 align="center">why should you use aurora?
</h2>

<br>

- aurora is a `fully open source` bot which means `no copyright`.
- this is the perfect base bot if you want to start your own bot community.
- aurora has a pre installed chatbot, dependencies updated and api provided which means you should not need update dependencies or create apis by your own. 
- new weeb section for your otaku friends.
- aurora has above 100 commands but usefull which means it will not take more space means always online. 
- aurora has `RPG and Economy and Games` which means you can use it as a `RPG Bot` or `Casino Bot`.
- aurora has ` User / Group Banning` which means you can use it as a `Anti Spam Bot` to avoid bot number ban.
- aurora has command toggeling function by that you can disable a command and work on it without turning bot off.
- aurora is a Folder Type bot which represents `Highest Stability`, `Highest Performance` and `Developer / User friendly`.
- aurora comes with [MIT](https://github.com/Kingshisui00/Aurora-Private/blob/main/LICENSE.md) License which means you can use it as a `base for your own bot` and can `modify it as you want` and can `add your own features`.
- we are working on new public features like charagme and others. 

<br>

<h2 align="center">Main points
</h2>

<br>

- We are the one of the most stable whatsapp gamebot now.
- This bot contains the economy features.
- This bot have games function from classic type to latest.
- This bot have a mining style-based rpg game.
- Overall this is a good base bot to use. 

<br>

<h2 align="center">⚠️ Warning ⚠️
</h2>

<br>

- This bot is not made by WhatsApp.inc so overusing this bot may result in WhatsApp account ban to avoid this you may avoid spamming of commands.
- The main running file of this bot aurora.js is prefered to be not edited to avoid whatsapp connecting issues.
- The package json should and the yarn file should not get affected as it cause to major error.
- Do not try to do any thing with the databases ( economy, games, rpg or charagame) as it can cause auto-reseting or auto-adding of datas.
- If you Modify this bot and face any issues, I am not responsible for that because it is not possible for my team and me to help everyone in their own bots yeah we can support you sometimes not everytime so do at your own risk.
- This bot is made for `Educational / Fun / Group Management` purposes only. I and the team will not be responsible for any misuse of this bot.
- If you face and issue regarding your own modification try to delete that repo again fork and try again by test or debug if the devs not responding to you.

<br>

<h2 align="center">📛 Legal Disclaimer 📛
</h2>
<br>

- We suggest you to use your `Own MongoDB URL` while deploying inside `.env` or `Environment Variables`. That will increase your Privacy and Security.
- We don't recommend to change the `Command databases like rpg and economy` that we have added in our bot. `If you do so, you will be responsible for any issues and we will not provide any support if we are busy`.
- We will not be responsible for any issues caused by any individual hosting this bot and cause any harm to any Group `(So don't make someone Group Admin who you don't know just because they are hosting the Bot)`.
- We prefer that you should not do anything with the aurora.js as it is the main file of the bot which in return can harm your bot.
- Always try to avoid command spamming by making it private mode or banning spammers in order to save your bot from ban.
- Do not add or update any dependencies it is required as every dependencies has its own compability with others.
- Try to use our official api from our api repo.

<br>

---

<h2 align="center">🔰 Meet Team phoenix🔰
</h2>




## USER DEPARTMENT (some are mandetory)
- This is the miniature model of our private cardgame bot.
- if you spot any comment statments which starts with // read those either they can be the details of that code or there you will be asked to replace or provide your values.
- If you want to create commamds there is the command example file in src that will help you.
- If you are facing problems at anything go through every md in our bot so that might help you.
- If you are facing issues for the apis that are required dont forget to  check our aurora api repo for help.

## UPDATES
- Logo maker directory  may come soon.
- some exclusive commands may come this month
- bug fixes
- monthly maintainance


<a><img src="https://i.ibb.co/7Kk6XSg/Rainbow.gif" width="100%">

</div>
